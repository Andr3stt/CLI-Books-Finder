package io.github.davikosta.cli_books_finder.view;

public class MainView {
}
