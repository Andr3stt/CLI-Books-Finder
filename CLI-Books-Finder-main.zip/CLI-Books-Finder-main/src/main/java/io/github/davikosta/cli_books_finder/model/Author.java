package io.github.davikosta.cli_books_finder.model;

public class Author {
}
