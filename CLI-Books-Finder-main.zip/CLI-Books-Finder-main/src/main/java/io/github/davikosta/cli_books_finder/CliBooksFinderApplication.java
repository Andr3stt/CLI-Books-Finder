package io.github.davikosta.cli_books_finder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CliBooksFinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(CliBooksFinderApplication.class, args);
	}

}
