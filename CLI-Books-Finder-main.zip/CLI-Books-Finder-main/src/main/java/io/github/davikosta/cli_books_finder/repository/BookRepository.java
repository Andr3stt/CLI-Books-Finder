package io.github.davikosta.cli_books_finder.repository;

public class BookRepository {
}
