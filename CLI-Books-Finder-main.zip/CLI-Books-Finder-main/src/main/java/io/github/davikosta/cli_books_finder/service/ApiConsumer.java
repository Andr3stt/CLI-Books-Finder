package io.github.davikosta.cli_books_finder.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class ApiConsumer {

    private final WebClient webClient;

    public ApiConsumer(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder
                .baseUrl("https://gutendex.com/books")
                .build();
    }

    /**
     * Busca dados na API a partir de um parâmetro de busca.
     * @param searchTerm Termo para ser usado na query de busca (ex: "don+quixote")
     * @return O corpo da resposta como String (JSON)
     */
    public String fetchData(String searchTerm) {
        String uri = "/?search=" + searchTerm;

        return this.webClient.get()
                .uri(uri)
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }
}
