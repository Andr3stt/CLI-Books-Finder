package io.github.davikosta.cli_books_finder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CliBooksFinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
